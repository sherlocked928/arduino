interface IAction {
  Icon: any;
  name: string;
  isOn: boolean;
}
export default function Action({ Icon, name, isOn }: IAction) {
  return (
    <div className={`action ${isOn ? "ON" : ""}`}>
      <div className="action-icon">
        <Icon />
      </div>
      <div className="action-name">{name}</div>
    </div>
  );
}
