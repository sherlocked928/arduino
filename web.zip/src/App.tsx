import Card from "./Card";
import List from "./Icons/List";
import Sensor from "./assets/temperature-sensor.svg?react";
import Ultrasonic from "./assets/ultrasonic-distance-sensor.svg?react";
import Tv from "./assets/old-tv.svg?react";
import Bulb from "./assets/electric-light-bulb.svg?react";
import Action from "./Action";
function App() {
  return (
    <>
      <header>
        <div className="banner">
          <h1>Arduino Project</h1>
          <span className="burger-icon">
            <List />
          </span>
        </div>
      </header>
      <main>
        <div className="cards">
          <Card
            Icon={Sensor}
            name={"DHT11"}
            description="a basic, ultra low-cost digital temperature and humidity sensor"
            title="Temperature"
            value={"22.7"}
            Unit={"°C"}
          />
          <Card
            Icon={Ultrasonic}
            name={"Ultrasonic"}
            description="an instrument that measures the distance to an object using ultrasonic sound waves"
            title="Proximity"
            value={"0.2"}
            Unit={"CM"}
          />
        </div>
        <div className="auto-mode">
          <label htmlFor="autoMode">Mode Automatique</label>
          <input type="checkbox" id="autoMode" className="switch" />
        </div>
        <div className="action-container">
          <Action Icon={Tv} name="Télévision" isOn={true} />
          <Action Icon={Bulb} name="Living Room" isOn={false} />
          <Action Icon={Bulb} name="Kitchen" isOn={true} />
          <Action Icon={Tv} name="Télévision" isOn={false} />
          <Action Icon={Bulb} name="Living Room" isOn={false} />
          <Action Icon={Bulb} name="Kitchen" isOn={true} />
        </div>
      </main>
    </>
  );
}

export default App;
