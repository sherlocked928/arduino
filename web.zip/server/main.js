import express from "express";
import { WebSocketServer } from "ws";
import path from "path";

const __dirname = path.resolve();
console.log(__dirname);
const app = express();
const port = process.env.PORT || 3000;
const server = app.listen(port, () => {
  console.log(`Server listening on port ${port}`);
});
const wss = new WebSocketServer({ server });

wss.on("connection", (ws) => {
  console.log("Client connected");
  ws.send(JSON.stringify({ message: "Connected" }));
  ws.on("message", (message) => {
    console.log("Received message:", message.toString());
    ws.send(`You sent: ${message}`);
  });

  ws.on("close", () => {
    console.log("Client disconnected");
  });
});

app.use(express.static(path.join(__dirname, "/dist")));

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "/dist/index.html"));
});
